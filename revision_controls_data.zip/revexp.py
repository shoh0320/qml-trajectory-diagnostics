"""Revision experiments: independent S-V-T split, transfer-rich family, fixed-term-count, depolarizing noise.
Reuses the paper's pipeline functions (scaling_sweep.py): Reptile meta-init (200 outer, K=10, lr 0.5/0.3, init 0.1)."""
import sys, os, json, time, numpy as np, pandas as pd, pennylane as qml
from pennylane import numpy as pnp
from scipy import stats
import scaling_sweep as ss

def draw_coeffs_corr(rng, n, lo=0.5, hi=1.5, aniso=0.15, field_scale=0.5, site_noise=0.15):
    """Transfer-rich family: XX/YY/ZZ on a bond share one coupling (small anisotropy); fields share a common value."""
    M, nb = 4*n-3, n-1
    J = rng.uniform(lo, hi, size=nb) * rng.choice([-1.0, 1.0], size=nb)
    c = np.empty(M)
    for b in range(nb):
        for a in range(3):
            c[3*b+a] = J[b] * (1.0 + aniso*rng.normal())
    h = rng.normal(0.0, field_scale)
    c[3*nb:] = h + site_noise*rng.normal(size=n)
    return c


def draw_coeffs_unif(rng, n, lo=0.5, hi=1.5, aniso=0.05, bond_noise=0.05, field_scale=0.5, site_noise=0.05):
    """Strong-transfer family: one coupling J for all bonds and all XX/YY/ZZ (5% noise), one common field h (5% site noise)."""
    M, nb = 4*n-3, n-1
    J = rng.uniform(lo, hi) * rng.choice([-1.0, 1.0])
    c = np.empty(M)
    for b in range(nb):
        Jb = J * (1.0 + bond_noise*rng.normal())
        for a in range(3):
            c[3*b+a] = Jb * (1.0 + aniso*rng.normal())
    h = rng.normal(0.0, field_scale)
    c[3*nb:] = h * (1.0 + site_noise*rng.normal(size=n))
    return c

def split3(rng, M, fr=(0.5, 0.25, 0.25)):
    perm = rng.permutation(M); s = int(round(fr[0]*M)); v = int(round(fr[1]*M))
    return perm[:s], perm[s:s+v], perm[s+v:]

def make_loss(dev, n, L, coeffs, ops, p):
    denom = float(np.sum(np.abs(coeffs))) or 1.0
    H = qml.Hamiltonian([float(x)/denom for x in coeffs], list(ops))
    @qml.qnode(dev, diff_method="backprop")
    def qn(theta):
        for l in range(L):
            for w in range(n):
                qml.RY(theta[l, w, 0], wires=w); qml.RZ(theta[l, w, 1], wires=w)
            for w in range(n-1): qml.CNOT(wires=[w, w+1])
            if p > 0:
                for w in range(n): qml.DepolarizingChannel(p, wires=w)
        return qml.expval(H)
    return qn

def grad(qn, th): return np.asarray(qml.grad(qn)(th), dtype=float).reshape(-1)

def task_draw(rng, n, ops, family, split, fixed_M):
    c = {"orig": ss.draw_coeffs, "corr": draw_coeffs_corr, "unif": draw_coeffs_unif}[family](rng, n)
    idx = np.arange(len(ops))
    if fixed_M: idx = rng.choice(len(ops), fixed_M, replace=False)
    c_act, ops_act = c[idx], [ops[j] for j in idx]
    if split == "2way":
        S, V = ss.split_indices(rng, len(idx)); T = None
    else:
        S, V, T = split3(rng, len(idx))
    return c_act, ops_act, S, V, T

def run_cfg(cfg):
    n, L, seed = cfg["n"], cfg["L"], cfg["seed"]; family, split = cfg["family"], cfg["split"]
    fixed_M, p = cfg.get("fixed_M"), cfg.get("noise", 0.0)
    K, inner_lr, outer_lr, n_outer, n_eval, init_scale = 10, 0.5, 0.3, cfg.get("n_outer", 200), cfg.get("n_eval", 50), 0.1
    dev = qml.device("default.mixed" if p > 0 else "default.qubit", wires=n)
    ops = ss.build_ops(n)
    rng = np.random.default_rng(cfg.get("base", 0) + 1000*n + 100*L + seed)
    # Reptile meta-initialization on support losses of the family
    theta = pnp.array(rng.normal(0.0, init_scale, size=(L, n, 2)), requires_grad=True)
    for _ in range(n_outer):
        c, oa, S, V, T = task_draw(rng, n, ops, family, split, fixed_M)
        qS = make_loss(dev, n, L, c[S], [oa[j] for j in S], p)
        phi = pnp.array(theta, requires_grad=True)
        for _ in range(K):
            phi = pnp.array(phi - inner_lr*qml.grad(qS)(phi), requires_grad=True)
        theta = pnp.array(theta + outer_lr*(phi - theta), requires_grad=True)
    rows = []
    for t in range(n_eval):
        c, oa, S, V, T = task_draw(rng, n, ops, family, split, fixed_M)
        qS = make_loss(dev, n, L, c[S], [oa[j] for j in S], p)
        qV = make_loss(dev, n, L, c[V], [oa[j] for j in V], p)
        qT = make_loss(dev, n, L, c[T], [oa[j] for j in T], p) if T is not None else None
        gS, gV = grad(qS, theta), grad(qV, theta)
        r = dict(n=n, L=L, seed=seed, task=t, family=family, split=split, fixed_M=fixed_M or 0, noise=p,
                 norm_gS=float(np.linalg.norm(gS)), norm_gV=float(np.linalg.norm(gV)),
                 A_V=float(gS@gV/(np.linalg.norm(gS)*np.linalg.norm(gV))),
                 LS0=float(qS(theta)), LV0=float(qV(theta)))
        if qT is not None:
            gT = grad(qT, theta); r["A_T"] = float(gS@gT/(np.linalg.norm(gS)*np.linalg.norm(gT))); r["LT0"] = float(qT(theta))
        phi = pnp.array(theta, requires_grad=True)
        for _ in range(K):
            phi = pnp.array(phi - inner_lr*qml.grad(qS)(phi), requires_grad=True)
        r["LSK"], r["LVK"] = float(qS(phi)), float(qV(phi))
        r["I_S"], r["I_V"] = r["LS0"]-r["LSK"], r["LV0"]-r["LVK"]; r["G_V"] = r["LVK"]-r["LSK"]
        if qT is not None:
            r["LTK"] = float(qT(phi)); r["I_T"] = r["LT0"]-r["LTK"]; r["G_T"] = r["LTK"]-r["LSK"]
        r["drift"] = float(np.linalg.norm(np.asarray(phi, dtype=float).reshape(-1) - np.asarray(theta, dtype=float).reshape(-1)))
        rows.append(r)
    df = pd.DataFrame(rows)
    # barren-plateau probe at random init on the same (possibly fixed-M) support loss
    if cfg.get("bp_probe"):
        comp, norms = [], []
        for _ in range(cfg["bp_probe"]):
            c, oa, S, V, T = task_draw(rng, n, ops, family, split, fixed_M)
            qS = make_loss(dev, n, L, c[S], [oa[j] for j in S], p)
            th = pnp.array(rng.uniform(0, 2*np.pi, size=(L, n, 2)), requires_grad=True)
            g = grad(qS, th); comp.append(g[0]); norms.append(np.linalg.norm(g))
        df["bp_var"] = float(np.var(comp)); df["bp_norm_mean"] = float(np.mean(norms))
    return df

if __name__ == "__main__":
    plan = json.load(open(sys.argv[1])); os.makedirs("rev_results", exist_ok=True)
    for cfg in plan:
        tag = f"{cfg['family']}_{cfg['split']}_n{cfg['n']}_L{cfg['L']}_M{cfg.get('fixed_M') or 0}_p{cfg.get('noise',0)}_s{cfg['seed']}"
        out = f"rev_results/{tag}.csv"
        if os.path.exists(out): print("skip", tag, flush=True); continue
        t0 = time.time(); df = run_cfg(cfg); df.to_csv(out, index=False)
        s = f"[{tag}] {time.time()-t0:.0f}s  mean I_V={df.I_V.mean():+.3f}  rho(A_V,I_V)={stats.spearmanr(df.A_V, df.I_V)[0]:+.3f}"
        if "I_T" in df: s += f"  mean I_T={df.I_T.mean():+.3f}  rho(A_V,I_T)={stats.spearmanr(df.A_V, df.I_T)[0]:+.3f}"
        print(s, flush=True)
    print("PLAN DONE", flush=True)
