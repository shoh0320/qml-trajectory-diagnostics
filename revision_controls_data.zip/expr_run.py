import numpy as np, pandas as pd, pennylane as qml, time
from scipy import stats
import scaling_sweep as ss
rows = []; t0 = time.time()
for n in [4, 6, 8, 10]:
    dev = qml.device("default.qubit", wires=n); N = 2**n
    for L in [2, 3, 5]:
        @qml.qnode(dev)
        def st(theta):
            ss.ansatz(theta, n, L); return qml.state()
        rng = np.random.default_rng(1234 + n*10 + L)
        F = np.array([abs(np.vdot(st(rng.uniform(0, 2*np.pi, size=(L, n, 2))), st(rng.uniform(0, 2*np.pi, size=(L, n, 2)))))**2 for _ in range(1000)])
        bins = np.linspace(0, 1, 76); p_pqc = np.histogram(F, bins=bins)[0]/len(F)
        p_haar = np.diff([1-(1-b)**(N-1) for b in bins]); m = p_pqc > 0
        kl = float(np.sum(p_pqc[m]*np.log(p_pqc[m]/p_haar[m])))
        rows.append(dict(n=n, L=L, d=2*n*L, expr_KL=round(kl, 3), meanF=round(float(F.mean()), 4), haar_meanF=round(1/N, 4)))
        print(n, L, round(kl,3), flush=True)
ex = pd.DataFrame(rows)
summ = pd.read_csv("repo/data/results_summary.csv").groupby(["n","L"]).agg(cv=("cv_gtr","mean"), mnorm=("mean_norm_gtr","mean"), ident=("rho_A_Ival","mean")).reset_index()
mg = ex.merge(summ, on=["n","L"]); mg.to_csv("rev_results_expressibility.csv", index=False)
for col in ["cv","mnorm","ident"]: print(f"Spearman(expr_KL,{col}) = {stats.spearmanr(mg.expr_KL, mg[col])[0]:+.3f}", flush=True)
print("EXPR DONE", f"{time.time()-t0:.0f}s", flush=True)
