import glob, os, numpy as np, pandas as pd
from scipy import stats
def rho(x, y): return stats.spearmanr(x, y)[0]
def partial(x, y, Z):
    xr, yr = stats.rankdata(x), stats.rankdata(y)
    Zr = np.column_stack([stats.rankdata(z) for z in Z] + [np.ones(len(xr))])
    rx = xr - Zr @ np.linalg.lstsq(Zr, xr, rcond=None)[0]; ry = yr - Zr @ np.linalg.lstsq(Zr, yr, rcond=None)[0]
    return stats.pearsonr(rx, ry)[0]
def load():
    fs = sorted(glob.glob("rev_results/*.csv")); df = pd.concat([pd.read_csv(f) for f in fs], ignore_index=True) if fs else pd.DataFrame()
    return df
def cfg_key(d): return (d.family.iloc[0], d.split.iloc[0], int(d.n.iloc[0]), int(d.L.iloc[0]), int(d.fixed_M.iloc[0]), float(d.noise.iloc[0]))
def stats_block(d):
    out = dict(n_tasks=len(d), seeds=d.seed.nunique(), mean_IV=d.I_V.mean(), sd_IV=d.I_V.std(), se_IV=d.I_V.std()/np.sqrt(len(d)),
               rho_AV_IV=rho(d.A_V, d.I_V), raw_AV_GV=rho(d.A_V, d.G_V), AV_GV_given_IV=partial(d.A_V, d.G_V, [d.I_V]),
               AV_GV_joint=partial(d.A_V, d.G_V, [d.I_V, d.LV0]), cv_gS=d.norm_gS.std()/d.norm_gS.mean(), mean_norm_gS=d.norm_gS.mean(), mean_drift=d.drift.mean())
    if "I_T" in d and d.I_T.notna().all():
        out.update(mean_IT=d.I_T.mean(), se_IT=d.I_T.std()/np.sqrt(len(d)), rho_AV_IT=rho(d.A_V, d.I_T), rho_AT_IT=rho(d.A_T, d.I_T), rho_AV_AT=rho(d.A_V, d.A_T),
                   raw_AV_GT=rho(d.A_V, d.G_T), AV_GT_given_IV=partial(d.A_V, d.G_T, [d.I_V]), AV_GT_joint_IV_LT0=partial(d.A_V, d.G_T, [d.I_V, d.LT0]),
                   AV_GT_joint_IT_LT0=partial(d.A_V, d.G_T, [d.I_T, d.LT0]), rho_IV_IT=rho(d.I_V, d.I_T))
    if "bp_var" in d: out.update(bp_var=d.bp_var.mean(), bp_norm_mean=d.bp_norm_mean.mean())
    return out
if __name__ == "__main__":
    df = load()
    if df.empty: print("no results"); raise SystemExit
    rows, per_seed = [], []
    for key, d in df.groupby(["family", "split", "n", "L", "fixed_M", "noise"]):
        s = stats_block(d); s.update(dict(zip(["family","split","n","L","fixed_M","noise"], key))); rows.append(s)
        for sd, ds in d.groupby("seed"):
            q = stats_block(ds); q.update(dict(zip(["family","split","n","L","fixed_M","noise"], key))); q["seed"] = sd; per_seed.append(q)
    pooled, seeds = pd.DataFrame(rows), pd.DataFrame(per_seed)
    os.makedirs("rev_tables", exist_ok=True); pooled.to_csv("rev_tables/pooled.csv", index=False); seeds.to_csv("rev_tables/per_seed.csv", index=False)
    pd.set_option("display.width", 250); pd.set_option("display.max_columns", 40)
    cols = [c for c in ["family","split","n","fixed_M","noise","seeds","mean_IV","se_IV","mean_IT","se_IT","rho_AV_IV","rho_AV_IT","rho_AT_IT","raw_AV_GV","AV_GV_joint","raw_AV_GT","AV_GT_given_IV","AV_GT_joint_IV_LT0","AV_GT_joint_IT_LT0","cv_gS","mean_norm_gS","bp_var"] if c in pooled]
    print(pooled[cols].round(3).to_string(index=False))
    print("\n--- per-seed ranges (key quantities) ---")
    for key, g in seeds.groupby(["family","split","n","fixed_M","noise"]):
        line = f"{key}: rho_AV_IV {g.rho_AV_IV.min():+.2f}..{g.rho_AV_IV.max():+.2f} | joint_GV {g.AV_GV_joint.min():+.2f}..{g.AV_GV_joint.max():+.2f}"
        if "rho_AV_IT" in g and g.rho_AV_IT.notna().all(): line += f" | rho_AV_IT {g.rho_AV_IT.min():+.2f}..{g.rho_AV_IT.max():+.2f} | raw_GT {g.raw_AV_GT.min():+.2f}..{g.raw_AV_GT.max():+.2f} | joint_GT(IT,LT0) {g.AV_GT_joint_IT_LT0.min():+.2f}..{g.AV_GT_joint_IT_LT0.max():+.2f}"
        print(line)
